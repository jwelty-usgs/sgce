#-----------------------------------------------------------------#
#Check_CED_Geodatabase_Fields.py
#Created on: 20140925
#Last modified on: 20140925
#Author: Justin Welty
#Description: Checks the final CED Geodatabase with all attribute
#             data to ensure fields do not contain obvious errors.
#-----------------------------------------------------------------#

# Import and create necessary objects
import arcpy
from arcpy import env
import sys
   
#Set the error warning value
errorwarn = 0

# Load parameters from tool
fc = arcpy.GetParameter(0)

# Determine if the feature count is greater than 0
try:
    Cnt = int(arcpy.GetCount_management(fc).getOutput(0))
    if Cnt > 0:
        arcpy.AddMessage("Features identified checking for appropriate fields")
    else:
        arcpy.AddError("Major Error: This feature class does not contain any features.  Please select the CED geodatabase feature class.")
        sys.exit()
except:
    arcpy.AddError("Major Error: This feature class does not contain any features.  Please select the CED geodatabase feature class.")
    sys.exit()

# Determine if the appropriate fields exist within the CED attribute table
exitscript = 0
try:
    fieldlistcheck = ['Effort_Name','TypeAct','Activity','SubActivity','Metric','Metric_Value','Primary_Threat','Secondary_Threat','Tertiary_Threat','Quaternary_Threat','Quinary_Threat','Agreement_Length','Agreement_Penalty','Agree_Protect_Ag_Conv','Agree_Protect_Imp_Graze','Agree_Protect_Infast','Agree_Protect_Mining','Agree_Protect_Energy_Devel','Agree_Protect_Rec','Agree_Protect_Sage_Elim','Agree_Protect_Urban_and_Subdiv','Objectives','Primary_Ownership','Secondary_Ownership','Tertiary_Ownership','Quaternary_Ownership','Quinary_Ownership','Implementation_Status','Start_Date','Finish_Date','No_Finish_In_Perpetuity','Activity_Effective','Explain_Activity_Effectiveness','HLC_Activity_Implemented','HLC_Legal_Authority','HLC_Resources_Available','HLC_Reg_and_Procedure_Mech','HLC_Compliance','HLC_Vol_Participation','ANDE_Reduce_Threats','ANDE_Incremental_Objectives','ANDE_Quantifiable_Performance','ANDE_Adaptive_Management','Implementing_Party','Primary_Collaborating_Party','Secondary_Collaborating_Party','Tertiary_Collaborating_Party','Quaternary_Collaborating_Party','Quinary_Collaborating_Party','Notes','Document_1_Name_and_Extension','Document_2_Name_and_Extension','Document_3_Name_and_Extension','Document_4_Name_and_Extension','Document_5_Name_and_Extension']
    fieldlist = arcpy.ListFields(fc)
    for fieldcheck in fieldlistcheck:
        fldexists = 0
        for field in fieldlist:
            if fieldcheck.lower() == field.name.lower():
                fldexists = 1
        if fldexists == 0:    
            exitscript = 1
            arcpy.AddError("Major Error: The field " + str(fieldcheck) + " does not exist, please ensure all CED attributes, even empty or null fields exist within the geodatabase.")
    if exitscript == 1:
        sys.exit()
    else:
        arcpy.AddMessage("All fields accounted for, good work so far, proceding to error check the records.")
except:
    arcpy.AddError("Major Error: The field check failed, please ensure your geodatabase is loaded correctly.")
    sys.exit()

# Scan through each row and ensure fields are complete
arcpy.AddWarning("Warning: The error check will go to completion, please look for any red errors to identify issues with the geodatabase fields.")
rows = arcpy.UpdateCursor(fc)
for row in rows:
    # Check for an effort name
    try:
        try:
            EFName = row.getValue("Effort_Name")
            if EFName > "":
                test = "Test"
            else:
                EFName = "'No Name for OBJECTID " + row.getValue("OBJECTID") + "'"
                arcpy.AddWarning("Error: An Effort Name for OBJECTID " +  + " is required.")
                errorwarn = errorwarn + 1
        except:
            EFName = "'No Name for OBJECTID " + str(row.getValue("OBJECTID")) + "'"
            arcpy.AddWarning("Error: An Effort Name for OBJECTID " + str(row.getValue("OBJECTID")) + " is required.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Effort Name field cannot be located, aborting the script.")
        sys.exit()

     #Check to ensure the subactivity field is completed and that it matches the activity selection
    try:
        typeactval = row.getValue("TypeAct")
        actval = row.getValue("Activity")
        subactval = row.getValue("SubActivity")
        if subactval > 0 and actval > 0 and typeactval > 0:
            #Check for a valid number range
            if subactval < 4 or subactval > 67:
                arcpy.AddWarning("Error: SubActivity for " + EFName + " must be valid entry from the drop down list.")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Non-regulatory Conservation Strategies    
            if typeactval == 3 and (subactval < 4 or subactval > 13):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Plan Activity selected(Non-regulatory Conservation Strategies).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Regulatory Mechanisms, Plans, Policy
            if typeactval == 4 and (subactval < 14 or subactval > 20):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Plan Activity selected (Regulatory Mechanisms, Plans, Policy).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Wildfire: Interagency Pre-suppression Planning Efforts
            if typeactval == 5 and (subactval < 21 or subactval > 24):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Plan Activity selected (Wildfire: Interagency Pre-suppression Planning Efforts).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Habitat Protection: Habitat Acquisition
            if typeactval == 6 and subactval != 25:
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Habitat Protection: Habitat Acquisition).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Habitat Protection: Conservation Easement
            if typeactval == 7 and subactval != 26:
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Habitat Protection: Conservation Easement).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Restoration: Infrastructure Removal, and Modification
            if typeactval == 8 and (subactval < 27 or subactval > 38):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Infrastructure Removal, and Modification).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Restoration: Livestock and Rangeland Management
            if typeactval == 9 and (subactval < 39 or subactval > 41):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Livestock and Rangeland Management).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Restoration: Recreation Management
            if typeactval == 10 and (subactval < 42 or subactval > 43):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Recreation Management).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Restoration: Conifer Removal
            if typeactval == 11 and (subactval < 44 or subactval > 47):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Conifer Removal).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Restoration: Habitat Reclamation Efforts
            if typeactval == 12 and (subactval < 48 or subactval > 49):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Habitat Reclamation Efforts).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Restoration: Habitat Reclamation Efforts
            if (typeactval == 13 and subactval != 50) or (typeactval == 13 and subactval != 55):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Habitat Restoration).")
                errorwarn = errorwarn + 1
                
            #Check subactivities for the activity Restoration: Population Augmentation
            if typeactval == 14 and subactval != 61:
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Population Augmentation).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Restoration: Wild Equid Management
            if typeactval == 17 and (subactval < 64 or subactval > 66):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Wild Equid Management).")
                errorwarn = errorwarn + 1

            #Check subactivities for the activity Restoration: Wildfire Pre-suppression Efforts
            if typeactval == 18 and (subactval < 65 or subactval > 67):
                arcpy.AddWarning("Error: SubActivity for " + EFName + " does not match the Project Activity selected (Restoration: Wildfire Pre-suppression Efforts).")
                errorwarn = errorwarn + 1
   
        else:
            # If the subactivity is complete but the typeact or activity are not autofill the typeact and activity fields
            if (subactval > 0 and actval < 3 and typeactval < 1) or (subactval > 0 and actval > 2 and typeactval < 1) or (subactval > 0 and actval < 3 and typeactval > 0) :
                arcpy.AddWarning("WARNING: The TypeAct and Activity fields are not fully complete for " + EFName + ". I am filling in the required fields using the subactivity value.")
                errorwarn = errorwarn + 1
                # Set TypeAct equal to Plan
                if subactval > 3 and subactval < 25:
                    row.setValue("TypeAct", 1)
                    rows.updateRow(row)

                # Set TypeAct equal to Project
                if subactval > 24 and subactval < 68:
                    row.setValue("TypeAct", 2)
                    rows.updateRow(row)

                # Set Activity equal to Non-regulatory Conservation Strategies
                if subactval > 3 and subactval < 14:
                    row.setValue("Activity", 3)
                    rows.updateRow(row)

                # Set Activity equal to Regulatory Mechanisms, Plans, Policy
                if subactval > 13 and subactval < 21:
                    row.setValue("Activity", 4)
                    rows.updateRow(row)

                # Set Activity equal to Wildfire: Interagency Pre-suppression Planning Efforts
                if subactval > 20 and subactval < 25:
                    row.setValue("Activity", 5)
                    rows.updateRow(row)

                # Set Activity equal to Habitat Protection: Conservation Easement
                if subactval == 25:
                    row.setValue("Activity", 6)
                    rows.updateRow(row)

                # Set Activity equal to Habitat Protection: Habitat Acquisition
                if subactval == 26:
                    row.setValue("Activity", 7)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Infrastructure Removal, and Modification
                if subactval > 26 and subactval < 39:
                    row.setValue("Activity", 8)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Livestock and Rangeland Management
                if subactval > 38 and subactval < 41:
                    row.setValue("Activity", 9)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Recreation Management
                if subactval > 41 and subactval < 44:
                    row.setValue("Activity", 10)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Conifer Removal
                if subactval > 43 and subactval < 48:
                    row.setValue("Activity", 11)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Habitat Reclamation Efforts
                if subactval > 47 and subactval < 50:
                    row.setValue("Activity", 12)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Habitat Restoration
                if subactval == 50 or subactval == 55:
                    row.setValue("Activity", 13)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Population Augmentation
                if subactval == 61:
                    row.setValue("Activity", 14)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Wild Equid Management
                if subactval == 64 and subactval == 65:
                    row.setValue("Activity", 17)
                    rows.updateRow(row)

                # Set Activity equal to Restoration: Wild Equid Management
                if subactval == 66 and subactval == 67:
                    row.setValue("Activity", 18)
                    rows.updateRow(row)

            else:
                arcpy.AddWarning("Error: SubActivity for " + EFName + " is required.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The SubActivity field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure that the TypeAct field is completed
    try:
        if typeactval > 0:
            if typeactval < 1 and typeactval > 2:
                arcpy.AddWarning("Error: TypeAct for " + EFName + " must be Plan or Project.")
                errorwarn = errorwarn + 1
        else:
            if subactval > 0:
                arcpy.AddWarning("Error: TypeAct for " + EFName + " is required.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The TypeAct field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the activity field is completed and that it matches the TypeAct Selection
    try:
        if actval > 0:
            if actval < 3 or actval > 18:
                arcpy.AddWarning("Error: Activity for " + EFName + " must be valid entry from the drop down list.")
                errorwarn = errorwarn + 1
            #Check if project is selected but a plan activity is selected
            if typeactval == 2 and (actval > 2 and actval < 6):
                arcpy.AddWarning("Error: Activity for " + EFName + " is a Plan value but your TypeAct has Project selected.")
                errorwarn = errorwarn + 1
            #Check if plan is selected but a pproject activity is selected
            if typeactval == 1 and (actval > 5 and actval < 19):
                arcpy.AddWarning("Error: Activity for " + EFName + " is a Project value but your TypeAct has Plan selected.")
                errorwarn = errorwarn + 1
        else:
            arcpy.AddWarning("Error: Activity for " + EFName + " is required.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Activity field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the metric field is completed and that it matches the SubActivity Selection
    try:
        metric = row.getValue("Metric")
        #Make sure the metric is a valid entry
        if metric > -1:
            if metric == 0 or metric == 1 or metric == 2 or metric == 3 or metric == 4 or metric == 5 or metric == 100 or metric == 101 or metric == 200 or metric == 201 or metric == 202 or metric == 203 or metric == 204 or metric == 205 or metric == 206 or metric == 300 or metric == 102 or metric == 207 or metric == 301 or metric == 208 or metric == 209 or metric == 210 or metric == 302 or metric == 103 or metric == 104 or metric == 211 or metric == 212 or metric == 105 or metric == 106 or metric == 107 or metric == 400 or metric == 500 or metric == 108 or metric == 213:
                test = "test"
            else:
                arcpy.AddWarning("Error: Metric for " + EFName + " must be valid entry from the drop down list.")
                errorwarn = errorwarn + 1
            #Check the Metric to ensure it matches the SubActivity
            # Set Metric = N/A
            if typeactval == 1 and metric != 0:
                arcpy.AddWarning("Error: There are no metric values for plans. The effort " + EFName + " is having it's metric set to 'N/A' and the metric value set to null.")
                errorwarn = errorwarn + 1
                row.setValue("Metric", 0)
                row.setValue("Metric_Value", None)
                rows.updateRow(row)

            # Set Metric equal to Total Acres
            if subactval == 25 or subactval == 26 or subactval == 39 or subactval == 40 or subactval == 44 or subactval == 45 or subactval == 46 or subactval == 47 or subactval == 48 or subactval == 49 or subactval == 50 or subactval == 55 or subactval == 67:
                if metric != 1:
                    if metric > 99 and metric < 200:
                        row.setValue("Metric", 1)
                        rows.updateRow(row)
                    else:
                        arcpy.AddWarning("Error: The metric for your SubActivity must be 'Total Acres'. The effort " + EFName + " is having it's metric set to 'Total Acres' please ensure that the Metric Value is correct.")
                        errorwarn = errorwarn + 1
                        row.setValue("Metric", 1)
                        rows.updateRow(row)

            # Set Metric equal to Total Miles
            if subactval == 27 or subactval == 28 or subactval == 29 or subactval == 30 or subactval == 31 or subactval == 32 or subactval == 33 or subactval == 36 or subactval == 37 or subactval == 41 or subactval == 42 or subactval == 43 or subactval == 66:
                if metric != 2:
                    if metric > 199 and metric < 300:
                        row.setValue("Metric", 2)
                        rows.updateRow(row)
                    else:
                        arcpy.AddWarning("Error: The metric for your SubActivity must be 'Total Miles'. The effort " + EFName + " is having it's metric set to 'Total Miles' please ensure that the Metric Value is correct.")
                        errorwarn = errorwarn + 1
                        row.setValue("Metric", 2)
                        rows.updateRow(row)

            # Set Metric equal to Total Number Removed
            if subactval == 34:
                if metric != 3:
                    if metric > 299 and metric < 400:
                        row.setValue("Metric", 3)
                        rows.updateRow(row)
                    else:
                        arcpy.AddWarning("Error: The metric for your SubActivity must be 'Total Number Removed'. The effort " + EFName + " is having it's metric set to 'Total Number Removed' please ensure that the Metric Value is correct.")
                        errorwarn = errorwarn + 1
                        row.setValue("Metric", 3)
                        rows.updateRow(row)

            # Set Metric equal to Total Birds
            if subactval == 61:
                if metric != 4:
                    if metric > 399 and metric < 500:
                        row.setValue("Metric", 4)
                        rows.updateRow(row)
                    else:
                        arcpy.AddWarning("Error: The metric for your SubActivity must be 'Total Birds'. The effort " + EFName + " is having it's metric set to 'Total Birds' please ensure that the Metric Value is correct.")
                        errorwarn = errorwarn + 1
                        row.setValue("Metric", 4)
                        rows.updateRow(row)

            # Set Metric equal to Total Number Equids
            if subactval == 64 or subactval == 65:
                if metric != 5:
                    if metric > 499 and metric < 600:
                        row.setValue("Metric", 5)
                        rows.updateRow(row)
                    else:
                        arcpy.AddWarning("Error: The metric for your SubActivity must be 'Total Number Equids'. The effort " + EFName + " is having it's metric set to 'Total Number Equids' please ensure that the Metric Value is correct.")
                        errorwarn = errorwarn + 1
                        row.setValue("Metric", 5)
                        rows.updateRow(row)

            # Test Metric where SubActivity equals Structure Removed: Other
            if subactval == 35:
                if metric != 1 or metric != 2 or metric != 3:
                    if metric == 102 or metric == 207 or metric == 301:
                        if metric == 102:
                            row.setValue("Metric", 1)
                            rows.updateRow(row)
                        if metric == 207:
                            row.setValue("Metric", 2)
                            rows.updateRow(row)
                        if metric == 301:
                            row.setValue("Metric", 3)
                            rows.updateRow(row)
                    else:
                        arcpy.AddWarning("Error: The metric for Structure Removed: Other must be Total Acres, Total Miles, or Total Number Removed. Please correct the metric and metric value for " + EFName + ".")
                        errorwarn = errorwarn + 1

            # Test Metric where SubActivity equals Structure Removed: Wind Turbines
            if subactval == 38:
                if metric != 2 or metric != 3:
                    if metric == 210 or metric == 302:
                        if metric == 210:
                            row.setValue("Metric", 2)
                            rows.updateRow(row)
                        if metric == 302:
                            row.setValue("Metric", 3)
                            rows.updateRow(row)
                    else:
                        arcpy.AddWarning("Error: The metric for Structure Removed: Wind Turbines must be Total Miles or Total Number Removed. Please correct the metric and metric value for " + EFName + ".")
                        errorwarn = errorwarn + 1              
        else:
            arcpy.AddWarning("Error: Metric for " + EFName + " is required.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Metric field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Metric Value field is completed correctly if it is entered
    try:
        if typeactval == 2:
            metvalval = row.getValue("Metric_Value")
            if float(metvalval) < 0.001:
                arcpy.AddWarning("Error: Metric Value for " + EFName + " a number value greater than 0'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Metric Value field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure that if the SubActivity Habitat Protection: Conservation Easement is selected that the fields Agreement Length and Agreement Penalty are completed
    try:
        if actval == 25:
            ALval = row.getValue("Agreement_Length_Cons_Easement_Only")
            APval = row.getValue("Agreement_Penalty_Cons_Easement_Only")
            if ALval < 1 or ALval > 8:
                arcpy.AddWarning("Error: Agreement_Length for " + EFName + " must be valid entry from the drop down list, Null or N/A are not allowed.")
                errorwarn = errorwarn + 1

            if APval < 1 or APval > 2:
                arcpy.AddWarning("Error: Agreement_Penalty for " + EFName + " must be valid entry from the drop down list, Null or N/A are not allowed.")
                errorwarn = errorwarn + 1

    except:
        arcpy.AddError("Major Error: The Agreement Length or Agreement Penalty fields cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Primary Threat field is completed
    try:
        threatval = row.getValue("Primary_Threat")
        if threatval > 0:
            if threatval < 1 or threatval > 13:
                arcpy.AddWarning("Error: Primary Threat for " + EFName + " is invalid. Please select a threat from the dropdown list.")
                errorwarn = errorwarn + 1
        else:
            arcpy.AddWarning("Error: Primary threat for " + EFName + " is required.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Primary Threat field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Secondary Threat field is completed correctly if it is entered
    try:
        threatval2 = row.getValue("Secondary_Threat")
        if threatval2 > 0:
            if threatval2 < 1 or threatval2 > 13:
                arcpy.AddWarning("Error: Secondary Threat for " + EFName + " is invalid. Please select a threat from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Secondary Threat field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Tertiary Threat field is completed correctly if it is entered
    try:
        threatval3 = row.getValue("Tertiary_Threat")
        if threatval3 > 0:
            if threatval3 < 1 or threatval3 > 13:
                arcpy.AddWarning("Error: Tertiary Threat for " + EFName + " is invalid. Please select a threat from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Tertiary Threat field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Quaternary Threat field is completed correctly if it is entered
    try:
        threatval4 = row.getValue("Quaternary_Threat")
        if threatval4 > 0:
            if threatval4 < 1 or threatval4 > 13:
                arcpy.AddWarning("Error: Quaternary Threat for " + EFName + " is invalid. Please select a threat from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Quaternary Threat field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Quinary Threat field is completed correctly if it is entered
    try:
        threatval5 = row.getValue("Quinary_Threat")
        if threatval5 > 0:
            if threatval5 < 1 or threatval5 > 13:
                arcpy.AddWarning("Error: Quinary Threat for " + EFName + " is invalid. Please select a threat from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Quinary Threat field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Objectives field is completed correctly if it is entered
    try:
        objval = row.getValue("Objectives")
        if objval > "":
            test = "Test"
        else:
            arcpy.AddWarning("Error: Objectives for " + EFName + " must contain detailed text of the objectives, please complete this field.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Objectives field cannot be located, aborting the script.")
        sys.exit()

   
    #Check to ensure the Primary Ownership field is completed
    try:
        Ownershipval = row.getValue("Primary_Ownership")

        if Ownershipval > 0:
            if Ownershipval < 1 or Ownershipval > 13:
                arcpy.AddWarning("Error: Primary Ownership for " + EFName + " is invalid. Please select an Ownership from the dropdown list.")
                errorwarn = errorwarn + 1
        else:
            arcpy.AddWarning("Error: Primary Ownership for " + EFName + " is required.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Primary Ownership field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Secondary Ownership field is completed correctly if it is entered
    try:
        Ownershipval2 = row.getValue("Secondary_Ownership")
        if Ownershipval2 > 0:
            if Ownershipval2 < 1 or Ownershipval2 > 13:
                arcpy.AddWarning("Error: Secondary Ownership for " + EFName + " is invalid. Please select an Ownership from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Secondary Ownership field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Tertiary Ownership field is completed correctly if it is entered
    try:
        Ownershipval3 = row.getValue("Tertiary_Ownership")
        if Ownershipval3 > 0:
            if Ownershipval3 < 1 or Ownershipval3 > 13:
                arcpy.AddWarning("Error: Tertiary Ownership for " + EFName + " is invalid. Please select an Ownership from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Tertiary Ownership field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Quaternary Ownership field is completed correctly if it is entered
    try:
        Ownershipval4 = row.getValue("Quaternary_Ownership")
        if Ownershipval4 > 0:
            if Ownershipval4 < 1 or Ownershipval4 > 13:
                arcpy.AddWarning("Error: Quaternary Ownership for " + EFName + " is invalid. Please select an Ownership from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Quaternary Ownership field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Quinary Ownership field is completed correctly if it is entered
    try:
        Ownershipval5 = row.getValue("Quinary_Ownership")
        if Ownershipval5 > 0:
            if Ownershipval5 < 1 or Ownershipval5 > 13:
                arcpy.AddWarning("Error: Quinary Ownership for " + EFName + " is invalid. Please select an Ownership from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Quinary Ownership field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Implementation Status field is completed correctly if it is entered
    try:
        statusval = row.getValue("Implementation_Status")
        if statusval < 1 or statusval > 3 :
            arcpy.AddWarning("Error: Implementation_Status for " + EFName + " must be 'Planned', 'In Progress', or 'Implemented'.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Implementation_Status field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Start_Date field is completed correctly if it is entered
    try:
        strtval = row.getValue("Start_Date")
        if str(strtval) > "":
            test = "Test"
        else:
            arcpy.AddWarning("Error: Start Date for " + EFName + " must contain a valid date, please complete this field.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Start Date field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Finish_Date field is completed correctly if it is entered
    try:
        fnshval = row.getValue("Finish_Date")
        inperpval = row.getValue("No_finish_In_Perpetuity")
        if str(fnshval) > "":
            test = "Test"
        else:
            if inperpval == 1:
                test = "Test"
            else:
                arcpy.AddWarning("Error: Finish Date for " + EFName + " must contain a valid date, please complete this field.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Finish Date field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Activity_Effective field is completed correctly if it is entered
    try:
        acteffval = row.getValue("Activity_Effective")
        if acteffval < 1 or acteffval > 2 :
            arcpy.AddWarning("Error: Activity_Effective for " + EFName + " must be 'Yes' or 'Yes, based on literature', or 'Too early to tell'.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Activity_Effective field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Explain_Activity_Effectiveness field is completed correctly if it is entered
    try:
        eaeval = row.getValue("Explain_Activity_Effectiveness")
        if eaeval > "":
            test = "Test"
        else:
            if acteffval == 1:
                arcpy.AddWarning("Error: Explain_Activity_Effectiveness for " + EFName + " must contain a detailed description of the reason , please complete this field.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Explain_Activity_Effectiveness field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the HLC_Activity_Implemented field is completed correctly if it is entered
    try:
        HLCAIval = row.getValue("HLC_Activity_Implemented")
        if (statusval == 1 or statusval == 2) and (HLCAIval < 1 or HLCAIval > 2):
            arcpy.AddWarning("Error: HLC_Activity_Implemented for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if HLCAIval > 0:
            if HLCAIval < 1 or HLCAIval > 2 :
                arcpy.AddWarning("Error: HLC_Activity_Implemented for " + EFName + " must be 'Yes' or 'No'.")
                errorwarn = errorwarn + 1
        
    except:
        arcpy.AddError("Major Error: The HLC_Activity_Implemented field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the HLC_Legal_Authority field is completed correctly if it is entered
    try:
        HLCLAval = row.getValue("HLC_Legal_Authority")
        if (statusval == 1 or statusval == 2) and (HLCLAval < 1 or HLCLAval > 2):
            arcpy.AddWarning("Error: HLC_Legal_Authority for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if HLCLAval > 0:
            if HLCLAval < 1 or HLCLAval > 2 :
                arcpy.AddWarning("Error: HLC_Legal_Authority for " + EFName + " must be 'Yes' or 'No'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The HLC_Legal_Authority field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the HLC_Resources_Available field is completed correctly if it is entered
    try:
        HLCRAval = row.getValue("HLC_Resources_Available")
        if (statusval == 1 or statusval == 2) and (HLCRAval < 1 or HLCRAval > 2):
            arcpy.AddWarning("Error: HLC_Resources_Available for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if HLCRAval > 0:
            if HLCRAval < 1 or HLCRAval > 2 :
                arcpy.AddWarning("Error: HLC_Resources_Available for " + EFName + " must be 'Yes' or 'No'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The HLC_Resources_Available field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the HLC_Reg_and_Procedure_Mech field is completed correctly if it is entered
    try:
        HLCRPMval = row.getValue("HLC_Reg_and_Procedure_Mech")
        if (statusval == 1 or statusval == 2) and (HLCRPMval < 1 or HLCRPMval > 2):
            arcpy.AddWarning("Error: HLC_Reg_and_Procedure_Mech for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if HLCRPMval > 0:
            if HLCRPMval < 1 or HLCRPMval > 2 :
                arcpy.AddWarning("Error: HLC_Reg_and_Procedure_Mech for " + EFName + " must be 'Yes' or 'No'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The HLC_Reg_and_Procedure_Mech field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the HLC_Compliance field is completed correctly if it is entered
    try:
        HLCCval = row.getValue("HLC_Compliance")
        if (statusval == 1 or statusval == 2) and (HLCCval < 1 or HLCCval > 2):
            arcpy.AddWarning("Error: HLC_Compliance for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if HLCCval > 0:
            if HLCCval < 1 or HLCCval > 2 :
                arcpy.AddWarning("Error: HLC_Compliance for " + EFName + " must be 'Yes' or 'No'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The HLC_Compliance field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the HLC_Vol_Participation field is completed correctly if it is entered
    try:
        HLCVPval = row.getValue("HLC_Vol_Participation")
        if (statusval == 1 or statusval == 2) and (HLCVPval < 0 or HLCVPval > 2):
            arcpy.AddWarning("Error: HLC_Vol_Participation for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if HLCVPval > 0:
            if HLCVPval < 0 or HLCVPval > 2 :
                arcpy.AddWarning("Error: HLC_Vol_Participation for " + EFName + " must be 'Yes', 'No',  or 'NA'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The HLC_Vol_Participation field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the ANDE_Reduce_Threats field is completed correctly if it is entered
    try:
        ANDERTval = row.getValue("ANDE_Reduce_Threats")
        if (acteffval == 2) and (ANDERTval < 0 or ANDERTval > 2):
            arcpy.AddWarning("Error: ANDE_Reduce_Threats for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if ANDERTval > 0:
            if ANDERTval < 1 or ANDERTval > 2 :
                arcpy.AddWarning("Error: ANDE_Reduce_Threats for " + EFName + " must be 'Yes', 'No'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The ANDE_Reduce_Threats field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the ANDE_Incremental_Objectives field is completed correctly if it is entered
    try:
        ANDEIOval = row.getValue("ANDE_Incremental_Objectives")
        if (acteffval == 2) and (ANDEIOval < 0 or ANDEIOval > 2):
            arcpy.AddWarning("Error: ANDE_Incremental_Objectives for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if ANDEIOval > 0:
            if ANDEIOval < 1 or ANDEIOval > 2 :
                arcpy.AddWarning("Error: ANDE_Incremental_Objectives for " + EFName + " must be 'Yes', 'No'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The ANDE_Incremental_Objectives field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the ANDE_Quantifiable_Performance field is completed correctly if it is entered
    try:
        ANDEQPval = row.getValue("ANDE_Quantifiable_Performance")
        if (acteffval == 2) and (ANDEQPval < 0 or ANDEQPval > 2):
            arcpy.AddWarning("Error: ANDE_Quantifiable_Performance for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if ANDEQPval > 0:
            if ANDEQPval < 1 or ANDEQPval > 2 :
                arcpy.AddWarning("Error: ANDE_Quantifiable_Performance for " + EFName + " must be 'Yes', 'No'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The ANDE_Quantifiable_Performance field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the ANDE_Adaptive_Management field is completed correctly if it is entered
    try:
        ANDEAMval = row.getValue("ANDE_Adaptive_Management")
        if (acteffval == 2) and (ANDEAMval < 0 or ANDEAMval > 2):
            arcpy.AddWarning("Error: ANDE_Adaptive_Management for " + EFName + " is required.")
            errorwarn = errorwarn + 1
        if ANDEAMval > 0:
            if ANDEAMval < 1 or ANDEAMval > 2 :
                arcpy.AddWarning("Error: ANDE_Adaptive_Management for " + EFName + " must be 'Yes', 'No'.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The ANDE_Adaptive_Management field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Implementing_Party field is completed correctly if it is entered
    try:
        imppartval = row.getValue("Implementing_Party")
        if imppartval > 0:
            if imppartval < 1 or imppartval > 19 :
                arcpy.AddWarning("Error: Implementing_Party for " + EFName + " is invalid. Please select a value from the drop down list")
                errorwarn = errorwarn + 1
        else:
            arcpy.AddWarning("Error: Implementing Party for " + EFName + " is required.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Implementing_Party field cannot be located, aborting the script.")
        sys.exit()

        #Check to ensure the Primary Collaborating_Party field is completed
    try:
        Collaborating_Partyval = row.getValue("Primary_Collaborating_Party")
        if Collaborating_Partyval > 0:
            if Collaborating_Partyval < 1 or Collaborating_Partyval > 19:
                arcpy.AddWarning("Error: Primary Collaborating_Party for " + EFName + " is invalid. Please select an Collaborating_Party from the dropdown list.")
                errorwarn = errorwarn + 1
        else:
            arcpy.AddWarning("Error: Primary Collaborating_Party for " + EFName + " is required.")
            errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Primary Collaborating_Party field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Secondary Collaborating_Party field is completed correctly if it is entered
    try:
        Collaborating_Partyval2 = row.getValue("Secondary_Collaborating_Party")
        if Collaborating_Partyval2 > 0:
            if Collaborating_Partyval2 < 1 or Collaborating_Partyval2 > 19:
                arcpy.AddWarning("Error: Secondary Collaborating_Party for " + EFName + " is invalid. Please select an Collaborating_Party from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Primary Collaborating_Party field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Tertiary Collaborating_Party field is completed correctly if it is entered
    try:
        Collaborating_Partyval3 = row.getValue("Tertiary_Collaborating_Party")
        if Collaborating_Partyval3 > 0:
            if Collaborating_Partyval3 < 1 or Collaborating_Partyval3 > 19:
                arcpy.AddWarning("Error: Tertiary Collaborating_Party for " + EFName + " is invalid. Please select an Collaborating_Party from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Tertiary Collaborating_Party field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Quaternary Collaborating_Party field is completed correctly if it is entered
    try:
        Collaborating_Partyval4 = row.getValue("Quaternary_Collaborating_Party")
        if Collaborating_Partyval4 > 0:
            if Collaborating_Partyval4 < 1 or Collaborating_Partyval4 > 19:
                arcpy.AddWarning("Error: Quaternary Collaborating_Party for " + EFName + " is invalid. Please select an Collaborating_Party from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Quaternary Collaborating_Party field cannot be located, aborting the script.")
        sys.exit()

    #Check to ensure the Quinary Collaborating_Party field is completed correctly if it is entered
    try:
        Collaborating_Partyval5 = row.getValue("Quinary_Collaborating_Party")
        if Collaborating_Partyval5 > 0:
            if Collaborating_Partyval5 < 1 or Collaborating_Partyval5 > 19:
                arcpy.AddWarning("Error: Quinary Collaborating_Party for " + EFName + " is invalid. Please select an Collaborating_Party from the dropdown list.")
                errorwarn = errorwarn + 1
    except:
        arcpy.AddError("Major Error: The Quinary Collaborating_Party field cannot be located, aborting the script.")
        sys.exit()

    

if errorwarn > 0:
    arcpy.AddError("A total of " + str(errorwarn) + " errors were discovered in your records. Please read over the list above and ensure they are all corrected before submitting your data.")
else:
    arcpy.AddMessage("Process Completed Successfull: All features appear to be complete, your data are now ready for submission to the CED.")

   
    
